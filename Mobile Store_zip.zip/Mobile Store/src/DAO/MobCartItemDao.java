package DAO;

import java.util.List;


import POJO.CartItem;

public interface MobCartItemDao {

    boolean addToCart(CartItem cart);
    
    List<CartItem> showCartList();
    
    List<CartItem> searchCartByEmailId(String cEmail);
    
    CartItem searchById(int cartid);
    
    boolean deleteCartById(int cartid);
    
    boolean deleteCartByEmail(String cEmail);
    
    boolean updateCart(int cartid, int quantity);
}
;

