package DAO;

import java.util.List;

import POJO.Order;

public interface Order1 {
	   boolean placeOrder(Order o);
	    Order showOrderById(int orderId);
	    List<Order> showAllOrder();
	    boolean changeOrderStatus(String orderStatus, int orderId);
	    List<Order> showMyOrderHistory(String emailId);
	    public double calculatebill(String emailId);
		
		
}
