package DAO;

import java.util.List;

import POJO.Customer;

public interface MobileCustomerDao {
	boolean addCustomer(Customer c);
	 boolean deleteCustomeremailId(String emailid);
	 boolean updateCustomer(Customer c);
	 List<Customer> searchByemailId(String emailId);
	 List<Customer> getAllCustomer();
}
