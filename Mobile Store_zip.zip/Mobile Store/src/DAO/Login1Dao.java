package DAO;

public interface Login1Dao {
	public boolean userLogin( String emailId,String custPass);
	  public boolean adminLogin( String ademailId,String adPass);

}
