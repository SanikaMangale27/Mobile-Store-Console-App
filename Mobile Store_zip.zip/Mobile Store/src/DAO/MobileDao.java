package DAO;

import java.util.List;

import POJO.MobilePojo;
import Test.MobileApp;

public interface MobileDao {
	
	    public boolean addMobile(MobilePojo m);
	    public boolean updateMobile(MobilePojo m);
	    public boolean deleteMobile(int mobileId);
	    public MobilePojo searchMobileById(int mobileId);
	    public List<MobilePojo> getAllMobiles();
	    public List<MobilePojo> searchMobileByName(String mobileName);
	    public List<MobilePojo> searchMobileByBrand(String mobileBrand);
	}


