package Test;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import DAO.MobileCustomerDao;
import IMPL.MobileCustomerDaoImpl;
import POJO.Customer;

public class MobileCustomerTest {

    public static void main(String[] args) {
        Customer c = new Customer();
        Scanner sc = new Scanner(System.in);
        MobileCustomerDaoImpl mcdi = new MobileCustomerDaoImpl();

        System.out.println("Enter Your Choice:");
        System.out.println("1--AddCustomer:");
        System.out.println("2--deleteCustomer By emailId");
        System.out.println("3--updateCustomer");
        System.out.println("4--SearchCustomer By emailId");
        System.out.println("5--Get All Customer");
        System.out.println("8--Exit");

        int choice = sc.nextInt();
        sc.nextLine();

        switch (choice) {
        case 1: {
            System.out.println("Enter emailId:");
            String emailId = sc.nextLine();

            System.out.println("Enter custName:");
            String custName = sc.nextLine();

            System.out.println("Enter custPass:");
            String custPass = sc.nextLine();

            System.out.println("Enter custAdd:");
            String custAdd = sc.nextLine();

            System.out.println("Enter contactNo:");
            String contactNo = sc.nextLine();

            System.out.println("Enter custLoc:");
            String custLoc = sc.nextLine();

            c = new Customer( emailId, custName, custPass, custAdd, contactNo, custLoc);

            boolean flag = mcdi.addCustomer(c);

            if (flag) {
                System.out.println("Successfully Inserted");
            } else {
                System.out.println("Not Inserted");
            }

            break;
        }

        case 2: {
            System.out.println("Enter existing emailId that you want to delete:");
            String emailId = sc.nextLine();
            boolean flag = mcdi.deleteCustomeremailId(emailId);
            if (flag) {
                System.out.println("Successfully Deleted");
            } else {
                System.out.println("Not Deleted");
            }
            break;
        }

        case 3: {
            System.out.println("Enter existing emailId for update:");
            String emailId = sc.nextLine();

            System.out.println("Enter custName:");
            String custName = sc.nextLine();

            System.out.println("Enter custPass:");
            String custPass = sc.nextLine();

            System.out.println("Enter custAdd:");
            String custAdd = sc.nextLine();

            System.out.println("Enter contactNo:");
            String contactNo = sc.nextLine();

            System.out.println("Enter custLoc:");
            String custLoc = sc.nextLine();

            // Setting values for the customer object
            c.setEmailId(emailId);
            c.setCustName(custName);
            c.setCustPass(custPass);
            c.setCustAdd(custAdd);
            c.setContactNo(contactNo);
            c.setCustLoc(custLoc);

            boolean flag = mcdi.updateCustomer(c);
            if (flag) {
                System.out.println("Successfully updated");
            } else {
                System.out.println("Not Updated");
            }
            break;
        }

        case 4: {
            System.out.println("Search Customer by emailId:");
            String emailId = sc.nextLine();
            List<Customer> l = mcdi.searchByemailId(emailId);
            Iterator<Customer> it = l.iterator();
            while (it.hasNext()) {
                System.out.println(it.next());
            }
            break;
        }

        case 5: {
            List<Customer> l = mcdi.getAllCustomer();
            if (l != null) {
                Iterator<Customer> it = l.iterator();
                while (it.hasNext()) {
                    System.out.println(it.next());
                }
            }
            break;
        }

        default:
            System.out.println("Invalid choice.");
            break;
        }

        sc.close();
    }
}
