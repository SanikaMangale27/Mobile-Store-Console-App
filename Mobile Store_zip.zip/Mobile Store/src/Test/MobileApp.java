package Test;

import java.util.List;
import java.util.Scanner;
import IMPL.MobileDaoImpl;
import POJO.MobilePojo;

public class MobileApp {

    public static void main(String[] args) {

        boolean flag;
        MobileDaoImpl mdi = new MobileDaoImpl();

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Your Choice:");
        System.out.println("1--Add Mobile");
        System.out.println("2--Update Mobile");
        System.out.println("3--Delete Mobile");
        System.out.println("4--Search Mobile By Id");
        System.out.println("5--Get All Mobiles");
        System.out.println("6--Search Mobile by Model");
        System.out.println("7--Search Mobile By Brand");
        System.out.println("8--Exit");

        int choice = sc.nextInt();

        switch (choice) {
            case 1: {
            
                sc.nextLine(); // Consume any leftover newline

                System.out.println("Enter brand:");
                String brand = sc.nextLine();

                System.out.println("Enter model:");
                String model = sc.nextLine();

                System.out.println("Enter price:");
                double price = Double.parseDouble(sc.nextLine());

                System.out.println("Enter description:");
                String desc = sc.nextLine();

                System.out.println("Enter image:");
                String image = sc.nextLine();

                MobilePojo mob1 = new MobilePojo(brand, model, price, desc, image);
                flag = mdi.addMobile(mob1);

               

                MobilePojo mob = new MobilePojo(brand, model, price, desc, image);
                flag = mdi.addMobile(mob);

                if (flag) {
                    System.out.println("Successfully Inserted");
                } else {
                    System.out.println("Not Inserted");
                }
                break;
            }

            case 2: {
                System.out.println("Enter existing mobile ID to update:");
                int id = sc.nextInt();

                System.out.println("Enter brand:");
                String brand = sc.next();

                System.out.println("Enter model:");
                String model = sc.next();

                System.out.println("Enter price:");
                sc.nextLine();  // Consume the newline left after nextInt
                double price = Double.parseDouble(sc.nextLine());

                System.out.println("Enter description:");
                String desc = sc.next();

                System.out.println("Enter image:");
                String image = sc.next();

                MobilePojo mob = new MobilePojo();
                mob.setMobileId(id);
                mob.setBrand(brand);
                mob.setModel(model);
                mob.setPrice(price);
                mob.setDesc(desc);
                mob.setImage(image);

                flag = mdi.updateMobile(mob);

                if (flag) {
                    System.out.println("Successfully Updated");
                } else {
                    System.out.println("Not Updated");
                }
                break;
            }

            case 3: {
                System.out.println("Enter mobile ID to delete:");
                int id = sc.nextInt();
                flag = mdi.deleteMobile(id);

                if (flag) {
                    System.out.println("Successfully Deleted");
                } else {
                    System.out.println("Not Deleted");
                }
                break;
            }

            case 4: {
                System.out.println("Enter mobile ID to search:");
                int id = sc.nextInt();

                MobilePojo m = mdi.searchMobileById(id);

                if (m != null) {
                    System.out.println(m);
                } else {
                    System.out.println("Mobile Not Found");
                }
                break;
            }

            case 5: {
                List<MobilePojo> list = mdi.getAllMobiles();
                if (list != null) {
                    for (MobilePojo mobile : list) {
                        System.out.println(mobile);
                    }
                }
                break;
            }

            case 6: {
                System.out.println("Enter model to search:");
                String model = sc.next();
                List<MobilePojo> list = mdi.searchMobileByName(model);
                if (list != null && !list.isEmpty()) {
                    for (MobilePojo mobile : list) {
                        System.out.println(mobile);
                    }
                } else {
                    System.out.println("No mobiles found for this model.");
                }
                break;
            }

            case 7: {
                System.out.println("Enter brand to search:");
                String brand = sc.next();
                List<MobilePojo> list = mdi.searchMobileByBrand(brand);

                if (list != null && !list.isEmpty()) {
                    for (MobilePojo mobile : list) {
                        System.out.println(mobile);
                    }
                } else {
                    System.out.println("No mobiles found for this brand.");
                }
                break;
            }

            case 8: {
                System.out.println("Exiting...");
                break;
            }

            default:
                System.out.println("Invalid choice.");
        }

        sc.close();
    }
}
