package Test;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;
import IMPL.MobCartItemDaoImpl;
import IMPL.Order1DaoImpl;
import POJO.CartItem;  // Changed Cart to CartItem
import POJO.Order;

public class OrderTest {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        MobCartItemDaoImpl cdi = new MobCartItemDaoImpl();
        Order1DaoImpl odi = new Order1DaoImpl();
        Order o = null;
        boolean exit = false;
        int option;

        do {
            System.out.println("1 - Place Order");
            System.out.println("2 - Show My Order History");
            System.out.println("3 - Exit");
            System.out.print("Enter option: ");
            option = sc.nextInt();
            sc.nextLine();

            switch (option) {
                case 1: {
                    System.out.println("Enter emailId:");
                    String emailId = sc.nextLine();

                    // Ensure you're using CartItem instead of Cart
                    List<CartItem> clist = cdi.searchCartByEmailId(emailId);  
                    if (clist != null && !clist.isEmpty()) {
                        for (CartItem c : clist) {  
                            System.out.println(c);
                            System.out.println("----------");
                        }

                        System.out.println("Proceed to buy? Enter yes or no.");
                        String answer = sc.next().toLowerCase();
                        sc.nextLine();

                        if (answer.equals("yes")) {
                            String orderStatus = "Processing...";
                            o = new Order();
                            o.setOrderStatus(orderStatus);
                            o.setEmailId(emailId);

                            boolean flag = odi.placeOrder(o);
                            if (flag) {
                                System.out.println("Your order has been placed.");
                                LocalTime time = LocalTime.now().plusHours(1);
                                System.out.println("Delivery will be done before: " + time);
                            } else {
                                System.out.println("Error while placing the order.");
                            }
                        } else if (answer.equals("no")) {
                            System.out.println("Thank you for being with us.");
                        } else {
                            System.out.println("Please provide answer in yes or no only!");
                        }
                    } else {
                        System.out.println("Your cart is empty.");
                    }

                    break;
                }

                case 2: {
                    System.out.println("Enter your emailId:");
                    String emailId = sc.nextLine();

                    List<Order> olist = odi.showMyOrderHistory(emailId);

                    if (olist != null && !olist.isEmpty()) {
                        for (Order o1 : olist) {
                            System.out.println("Order no: " + o1.getOrderId());
                            System.out.println("Order date: " + o1.getOrderDate().toLocalDateTime()
                                .format(DateTimeFormatter.ofPattern("dd-MM-yy HH-mm-ss")));
                            System.out.println("Bill: " + o1.getTotalBill());
                            System.out.println("Status: " + o1.getOrderStatus());
                            System.out.println("-------------------------------");
                        }
                    } else {
                        System.out.println("You have not ordered anything from us till now!");
                    }

                    break;
                }

                case 3: {
                    System.out.println("Exiting...");
                    exit = true;
                    break;
                }

                default: {
                    System.out.println("Invalid option. Please choose again.");
                }
            }
        } while (!exit);

        sc.close();
    }
}
