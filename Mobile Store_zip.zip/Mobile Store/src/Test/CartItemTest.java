package Test;

import java.util.List;
import java.util.Scanner;

import IMPL.LoginDaoImpl;
import IMPL.MobCartItemDaoImpl;
import IMPL.MobileDaoImpl;
import POJO.CartItem;
import POJO.MobilePojo;

public class CartItemTest {

	public static void main(String[] args) {
		    LoginDaoImpl ldi = new LoginDaoImpl();
	        MobileDaoImpl mdi = new MobileDaoImpl();
	        List<MobilePojo> mlist = null;
	        MobCartItemDaoImpl mcdi = new MobCartItemDaoImpl();
	        CartItem cartItem = null;
	        Scanner sc = new Scanner(System.in);

	        System.out.println("Enter emailid:");
	        String emailid = sc.nextLine();

	        System.out.println("Enter password:");
	        String password = sc.nextLine();

	        boolean login = ldi.userLogin(emailid, password);

	        if (login) {
	            System.out.println("Login successful");

	            boolean exit = false;

	            do {

	                System.out.println("\nMenu:");
	                System.out.println("1 - Add to cart");
	                System.out.println("2 - Show my cart");
	                System.out.println("3 - Update quantity of item");
	                System.out.println("4 - Delete item from cart");
	                System.out.println("5 - Clear my cart");
	                System.out.print("Enter your choice: ");
	                int option = sc.nextInt();
	                sc.nextLine();

	                switch (option) {
	                case 1: {
	                    mlist = mdi.getAllMobiles(); // Fetch all mobiles instead of food
	                    for (MobilePojo m : mlist) {
	                        System.out.println(m);
	                        System.out.println("---------");
	                    }

	                    System.out.println("Enter id of mobile that you want to add to cart:");
	                    int mobileId = sc.nextInt();
	                    sc.nextLine();

	                    System.out.println("Enter quantity of this mobile:");
	                    int quantity = sc.nextInt();
	                    sc.nextLine();
	                    
	                    CartItem cartItem1 = new CartItem();
	                    cartItem1.setMobileId(mobileId);
	                    cartItem1.setQuantity(quantity);
	                    cartItem1.setcEmail(emailid); // emailid we get when person is logging in

	                    boolean flag = mcdi.addToCart(cartItem1);

	                    if (flag)
	                        System.out.println("Mobile item added to cart successfully");
	                    else
	                        System.out.println("Error while adding this item to cart, Please try again");
	                    break;
	                }

	                case 2: {
	                    List<CartItem> clist = mcdi.searchCartByEmailId(emailid); // Get cart items by email
	                    if (clist == null || clist.isEmpty()) {
	                        System.out.println("Your cart is empty.");
	                    } else {
	                        double bill = 0;
	                        for (CartItem c1 : clist) {
	                            bill += c1.getTotalPrice(); 
	                            System.out.println(c1);
	                            System.out.println("----------");
	                        }
	                        System.out.println("Amount payable = " + bill); // Show total amount
	                    }
	                    break;
	                }

	                case 3:{
	                    System.out.println("Enter the cart id for the item whose quantity is to be changed:");
	                    int cartId = sc.nextInt();
	                    sc.nextLine();
	                    System.out.println("Enter the quantity of the item:");
	                    int quantity = sc.nextInt();
	                    boolean flag = mcdi.updateCart(cartId, quantity);
	                    if (flag) {
	                        System.out.println("Quantity of your mobile item has been changed successfully");
	                    } else {
	                        System.out.println("Error while changing quantity");
	                    }
	                    break;
	                }
	                case 4:{
	                    System.out.println("Enter the cartId of item to be deleted:");
	                    int cartId = sc.nextInt();    
	                    sc.nextLine();
	                    boolean flag = mcdi.deleteCartById(cartId);
	                    if (flag) {
	                        System.out.println("Mobile item deleted successfully");
	                    } else {
	                        System.out.println("Error while deleting mobile item");
	                    }
	                    break;
	                }
	                case 5:{
	                    System.out.println("Enter emailId to clear cart:");
	                    String cEmail = sc.nextLine();
	                    System.out.println("-------------");
	                    boolean flag = mcdi.deleteCartByEmail(cEmail);
	                    if (flag) {
	                        System.out.println("Successfully Deleted");
	                    } else {
	                        System.out.println("Not Deleted");
	                    }
	                    break;
	                }

	                } // switch closing

	            } while (!exit);

	        } else {
	            System.out.println("Login failed! Please check your email and password.");
	        } // if closing

	        sc.close();
	}

}
