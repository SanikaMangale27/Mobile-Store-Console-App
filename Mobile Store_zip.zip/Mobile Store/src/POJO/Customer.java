package POJO;

public class Customer {
    private int custId;
    private String emailId;
    private String custName;
    private String custPass;
    private String custAdd;
    private String contactNo;
    private String custLoc;

    public Customer() {
        super();
    }

    public Customer(String emailId, String custName, String custPass, String custAdd, String contactNo, String custLoc) {
        this.emailId = emailId;
        this.custName = custName;
        this.custPass = custPass;
        this.custAdd = custAdd;
        this.contactNo = contactNo;
        this.custLoc = custLoc;
    }

    public int getCustId() {
        return custId;
    }

    public void setCustId(int custId) {
        this.custId = custId;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    public String getCustPass() {
        return custPass;
    }

    public void setCustPass(String custPass) {
        this.custPass = custPass;
    }

    public String getCustAdd() {
        return custAdd;
    }

    public void setCustAdd(String custAdd) {
        this.custAdd = custAdd;
    }

    public String getContactNo() {
        return contactNo;
    }

    public void setContactNo(String contactNo) {
        this.contactNo = contactNo;
    }

    public String getCustLoc() {
        return custLoc;
    }

    public void setCustLoc(String custLoc) {
        this.custLoc = custLoc;
    }

    @Override
    public String toString() {
        return "Customer [custId=" + custId + ", emailId=" + emailId + ", custName=" + custName + ", custPass=" + custPass
                + ", custAdd=" + custAdd + ", contactNo=" + contactNo + ", custLoc=" + custLoc + "]";
    }
}
