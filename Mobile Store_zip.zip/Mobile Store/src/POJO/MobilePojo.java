package POJO;

public class MobilePojo {
    private int mobileId;
    private String brand;
    private String model;
    private double price;
    private String desc;
    private String image;

    // Default constructor
    public MobilePojo() {}

    // Parameterized constructor
    public MobilePojo(String brand, String model, double price, String desc, String image) {
        this.brand = brand;
        this.model = model;
        this.price = price;
        this.desc = desc;
        this.image = image;
    }

    // Getter and Setter methods
    public int getMobileId() {
        return mobileId;
    }

    public void setMobileId(int mobileId) {
        this.mobileId = mobileId;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    @Override
    public String toString() {
        return "MobilePojo [mobileId=" + mobileId + ", brand=" + brand + ", model=" + model + ", price=" + price
                + ", desc=" + desc + ", image=" + image + "]";
    }
}
