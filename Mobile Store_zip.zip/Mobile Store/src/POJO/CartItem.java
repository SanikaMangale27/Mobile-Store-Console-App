package POJO;

public class CartItem {

	private int cartid;
	private int mobileId;
	private String cEmail;
	private int quantity;
	private String mobileName;
	private double mobilePrice;
	private double totalPrice;

	public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

	public CartItem(int cartid, int mobileId, String cEmail, int quantity, String mobileName, double mobilePrice, double totalPrice) {
	        this.cartid = cartid;
	        this.mobileId = mobileId;
	        this.cEmail = cEmail;
	        this.quantity = quantity;
	        this.mobileName = mobileName;
	        this.mobilePrice = mobilePrice;
	        this.totalPrice = totalPrice;
	    }

	public CartItem() {
	    }

	public CartItem(int mobileId, String cEmail, int quantity) {
	        this.mobileId = mobileId;
	        this.cEmail = cEmail;
	        this.quantity = quantity;
	    }

	public int getCartid() {
		return cartid;
	}

	public void setCartid(int cartid) {
		this.cartid = cartid;
	}

	public int getMobileId() {
		return mobileId;
	}

	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}

	public String getcEmail() {
		return cEmail;
	}

	public void setcEmail(String cEmail) {
		this.cEmail = cEmail;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getMobileName() {
		return mobileName;
	}

	public void setMobileName(String mobileName) {
		this.mobileName = mobileName;
	}

	public double getMobilePrice() {
		return mobilePrice;
	}

	public void setMobilePrice(double mobilePrice) {
		this.mobilePrice = mobilePrice;
	}

	@Override
	public String toString() {
		return "Cart [cartid=" + cartid + ", mobileId=" + mobileId + ", cEmail=" + cEmail + ", quantity=" + quantity
				+ ", mobileName=" + mobileName + ", mobilePrice=" + mobilePrice + ", totalPrice=" + totalPrice + "]";
	}
}
