package POJO;

import java.sql.Timestamp;
import java.time.LocalDateTime;

public class Order {
    private int orderId;
    private int custId;
    private double totalBill;  
    private Timestamp orderDate;
    private String emailId;
    private String orderStatus;

    public Order() {
        super();
    }

    public Order(int orderId, int custId, double totalBill, Timestamp orderDate, String emailId, String orderStatus) {
        super();
        this.orderId = orderId;
        this.custId = custId;
        this.totalBill = totalBill;
        this.orderDate = orderDate;
        this.emailId = emailId;
        this.orderStatus = orderStatus;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getCustId() {
        return custId;
    }

    public void setCustId(int custId) {
        this.custId = custId;
    }

    public double getTotalBill() {
        return totalBill;
    }

    public void setTotalBill(double totalBill) {
        this.totalBill = totalBill;
    }

    public Timestamp getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Timestamp localDateTime) {
        this.orderDate = localDateTime;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    @Override
    public String toString() {
        return "Order [orderId=" + orderId + ", custId=" + custId + ", totalBill=" + totalBill + 
            ", orderDate=" + orderDate + ", emailId=" + emailId + ", orderStatus=" + orderStatus + "]";
    }
}
