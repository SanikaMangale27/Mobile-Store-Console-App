package IMPL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import DAO.MobileCustomerDao;
import POJO.Customer;
import UTILITY.DBUtility;

public class MobileCustomerDaoImpl implements MobileCustomerDao {

    @Override
    public boolean addCustomer(Customer c) {
        Connection con = DBUtility.getConnect();
        String sql = "INSERT INTO customer(emailId, custName, custPass, custAdd, contactNo, custLoc) VALUES(?,?,?,?,?,?)";

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, c.getEmailId());
            ps.setString(2, c.getCustName());
            ps.setString(3, c.getCustPass());
            ps.setString(4, c.getCustAdd());
            ps.setString(5, c.getContactNo());
            ps.setString(6, c.getCustLoc());

            int i = ps.executeUpdate();

            return i > 0; // If rows are affected, return true
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    @Override
    public boolean deleteCustomeremailId(String emailId) {
        Connection con = DBUtility.getConnect();
        String sql = "DELETE FROM customer WHERE emailId = ?";

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, emailId);

            int i = ps.executeUpdate();

            return i > 0; // If rows are affected, return true
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    @Override
    public boolean updateCustomer(Customer c) {
        Connection con = DBUtility.getConnect();
        String sql = "UPDATE customer SET custName = ?, custPass = ?, custAdd = ?, contactNo = ?, custLoc = ? WHERE emailId = ?";

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, c.getCustName());
            ps.setString(2, c.getCustPass());
            ps.setString(3, c.getCustAdd());
            ps.setString(4, c.getContactNo());
            ps.setString(5, c.getCustLoc());
            ps.setString(6, c.getEmailId());

            int i = ps.executeUpdate();

            return i > 0; // If rows are affected, return true
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    @Override
    public List<Customer> searchByemailId(String emailId) {
        List<Customer> list = new ArrayList<>();
        Connection con = DBUtility.getConnect();
        String sql = "SELECT * FROM customer WHERE emailId = ?";

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, emailId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Customer c = new Customer();
                c.setCustId(rs.getInt("custId"));
                c.setEmailId(rs.getString("emailId"));
                c.setCustName(rs.getString("custName"));
                c.setCustPass(rs.getString("custPass"));
                c.setCustAdd(rs.getString("custAdd"));
                c.setContactNo(rs.getString("contactNo"));
                c.setCustLoc(rs.getString("custLoc"));

                list.add(c);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    @Override
    public List<Customer> getAllCustomer() {
        Connection con = DBUtility.getConnect();
        String sql = "SELECT * FROM customer";

        List<Customer> list = new ArrayList<>();

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Customer c = new Customer();
                c.setCustId(rs.getInt("custId"));
                c.setEmailId(rs.getString("emailId"));
                c.setCustName(rs.getString("custName"));
                c.setCustPass(rs.getString("custPass"));
                c.setCustAdd(rs.getString("custAdd"));
                c.setContactNo(rs.getString("contactNo"));
                c.setCustLoc(rs.getString("custLoc"));

                list.add(c);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }
}
