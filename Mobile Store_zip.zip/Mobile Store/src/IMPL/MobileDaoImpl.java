package IMPL;

import java.sql.*;
import java.util.*;
import DAO.MobileDao;
import POJO.MobilePojo;
import Test.MobileApp;
import UTILITY.DBUtility;

public class MobileDaoImpl implements MobileDao {

	@Override
	public boolean addMobile(MobilePojo m) {
		Connection con = DBUtility.getConnect();
		String sql = "INSERT INTO mobiles(brand, model, price, `desc`, image) VALUES (?, ?, ?, ?, ?)";

		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, m.getBrand());
			ps.setString(2, m.getModel());
			ps.setDouble(3, m.getPrice());
			ps.setString(4, m.getDesc());
			ps.setString(5, m.getImage());

			int i = ps.executeUpdate();
			return i > 0;

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return false;
	}

	@Override
	public boolean updateMobile(MobilePojo m) {
		Connection con = DBUtility.getConnect();
		String sql = "UPDATE mobiles SET brand=?, model=?, price=?, `desc`=?, image=? WHERE mobile_id=?";

		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, m.getBrand());
			ps.setString(2, m.getModel());
			ps.setDouble(3, m.getPrice());
			ps.setString(4, m.getDesc());
			ps.setString(5, m.getImage());
			ps.setInt(6, m.getMobileId());

			int i = ps.executeUpdate();
			return i > 0;

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return false;
	}

	@Override
	public boolean deleteMobile(int mobileId) {
		Connection con = DBUtility.getConnect();
		String sql = "DELETE FROM mobiles WHERE mobile_id=?";

		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, mobileId);
			int i = ps.executeUpdate();
			return i > 0;

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return false;
	}

	@Override
	public MobilePojo searchMobileById(int mobileId) {
		Connection con = DBUtility.getConnect();
		String sql = "SELECT * FROM mobiles WHERE mobile_id=?";
		MobilePojo m = null;

		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, mobileId);
			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				m = new MobilePojo();
				m.setMobileId(rs.getInt("mobile_id"));
				m.setBrand(rs.getString("brand"));
				m.setModel(rs.getString("model"));
				m.setPrice(rs.getDouble("price"));
				m.setDesc(rs.getString("desc"));
				m.setImage(rs.getString("image"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return m;
	}

	@Override
	
	public List<MobilePojo> getAllMobiles(){
		Connection con = DBUtility.getConnect();
		String sql = "SELECT * FROM mobiles";
		List<MobilePojo> list = new ArrayList<>();

		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				MobilePojo m = new MobilePojo();
				m.setMobileId(rs.getInt("mobile_id"));
				m.setBrand(rs.getString("brand"));
				m.setModel(rs.getString("model"));
				m.setPrice(rs.getDouble("price"));
				m.setDesc(rs.getString("desc"));
				m.setImage(rs.getString("image"));
				list.add(m);
			}

		} catch (SQLException e){
			e.printStackTrace();
		}

		return list;
	}

	@Override
	public List<MobilePojo> searchMobileByBrand(String brand) {
		Connection con = DBUtility.getConnect();
		String sql = "SELECT * FROM mobiles WHERE brand=?";
		List<MobilePojo> list = new ArrayList<>();

		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, brand);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				MobilePojo m = new MobilePojo();
				m.setMobileId(rs.getInt(1));
				m.setBrand(rs.getString(2));
				m.setModel(rs.getString(3));
				m.setPrice(rs.getDouble(4));
				m.setDesc(rs.getString(5));
				m.setImage(rs.getString(6));
				list.add(m);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return list; // Return an empty list if no records are found
	}

	@Override
	public List<MobilePojo> searchMobileByName(String mobileName) {
		Connection con = DBUtility.getConnect();
		String sql = "SELECT * FROM mobiles WHERE model = ?";
		List<MobilePojo> list = new ArrayList<>();

		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, mobileName); // Set mobile name as parameter for the query
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				MobilePojo m = new MobilePojo();
				m.setMobileId(rs.getInt("mobile_id"));
				m.setBrand(rs.getString("brand"));
				m.setModel(rs.getString("model"));
				m.setPrice(rs.getDouble("price"));
				m.setDesc(rs.getString("desc"));
				m.setImage(rs.getString("image"));
				list.add(m); // Add mobile to the list
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return list; // Return list of mobiles matching the name

	}

}
