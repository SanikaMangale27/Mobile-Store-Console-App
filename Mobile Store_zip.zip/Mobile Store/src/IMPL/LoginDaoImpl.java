package IMPL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import DAO.Login1Dao;
import UTILITY.DBUtility;

public class LoginDaoImpl implements Login1Dao {

	@Override
	public boolean userLogin(String emailId, String custPass) {
		try {
			Connection con = DBUtility.getConnect();
			String sql = "SELECT * FROM customer WHERE emailId = ?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, emailId);

			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				String pass1 = rs.getString("custPass");
				if (pass1.equals(custPass)) {
					return true;
				} else {
					return false;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean adminLogin(String ademailId, String adPass) {
		// TODO Auto-generated method stub
		return false;
	}

}
