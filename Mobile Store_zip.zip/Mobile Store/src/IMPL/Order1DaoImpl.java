package IMPL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import DAO.Order1;
import POJO.Order;
import UTILITY.DBUtility;

public class Order1DaoImpl implements Order1 {
    private double totalBill;
    Connection con = null;
    PreparedStatement ps;
    ResultSet rs;
    String sql;

    @Override
    public boolean placeOrder(Order o) {
        try {
            Timestamp now = new Timestamp(System.currentTimeMillis());

            totalBill = calculatebill(o.getEmailId());
            con = DBUtility.getConnect();

            sql = "INSERT INTO orders (orderDate, totalBill, emailId, orderStatus) VALUES (?, ?, ?, ?)";
            ps = con.prepareStatement(sql);

            ps.setTimestamp(1, now);
            ps.setDouble(2, totalBill);
            ps.setString(3, o.getEmailId());
            ps.setString(4, o.getOrderStatus());

            int row = ps.executeUpdate();
            if (row > 0) {
                new MobCartItemDaoImpl().deleteCartByEmail(o.getEmailId());
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public Order showOrderById(int orderId) {
        con = DBUtility.getConnect();
        sql = "SELECT * FROM orders WHERE orderId = ?";

        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, orderId);
            rs = ps.executeQuery();

            if (rs.next()) {
                Order o = new Order();
                o.setOrderId(rs.getInt(1));
                o.setOrderDate(rs.getTimestamp(2));
                o.setTotalBill(rs.getDouble(3));
                o.setEmailId(rs.getString(4));
                o.setOrderStatus(rs.getString(5));
                return o;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Order> showAllOrder() {
        List<Order> olist = new ArrayList<>();
        con = DBUtility.getConnect();
        sql = "SELECT * FROM orders";

        try {
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                Order o = new Order();
                o.setOrderId(rs.getInt(1));
                o.setOrderDate(rs.getTimestamp(2));
                o.setTotalBill(rs.getDouble(3));
                o.setEmailId(rs.getString(4));
                o.setOrderStatus(rs.getString(5));
                olist.add(o);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return olist;
    }

    @Override
    public boolean changeOrderStatus(String orderStatus, int orderId) {
        con = DBUtility.getConnect();
        sql = "UPDATE orders SET orderStatus = ? WHERE orderId = ?";

        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, orderStatus);
            ps.setInt(2, orderId);
            int row = ps.executeUpdate();
            return row > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public List<Order> showMyOrderHistory(String emailId) {
        List<Order> olist = new ArrayList<>();
        con = DBUtility.getConnect();
        sql = "SELECT * FROM orders WHERE emailId = ?";

        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, emailId);
            rs = ps.executeQuery();

            while (rs.next()) {
                Order o = new Order();
                o.setOrderId(rs.getInt(1));
                o.setOrderDate(rs.getTimestamp(2));
                o.setTotalBill(rs.getDouble(3));
                o.setEmailId(rs.getString(4));
                o.setOrderStatus(rs.getString(5));
                olist.add(o);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return olist;
    }

    @Override
    public double calculatebill(String emailId) {
        con = DBUtility.getConnect();
        sql = "SELECT totalPrice FROM cart WHERE cEmail = ?";

        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, emailId);
            rs = ps.executeQuery();
            totalBill = 0;

            while (rs.next()) {
                totalBill += rs.getDouble("totalPrice");
            }
            return totalBill;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

	
}

	
