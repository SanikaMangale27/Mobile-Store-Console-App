package IMPL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import DAO.MobCartItemDao;
import POJO.CartItem;
import POJO.MobilePojo;
import UTILITY.DBUtility;

public class MobCartItemDaoImpl implements MobCartItemDao {

    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    int row;

    @Override
    public boolean addToCart(CartItem cartItem) {
        con = DBUtility.getConnect();
        String sql = "INSERT INTO cartitem (mobileId, cEmail, quantity, mobileName, mobilePrice, totalPrice) VALUES (?, ?, ?, ?, ?, ?)";
        try {
            MobilePojo m = new MobileDaoImpl().searchMobileById(cartItem.getMobileId());
            double totalPrice = m.getPrice() * cartItem.getQuantity();

            ps = con.prepareStatement(sql);
            ps.setInt(1, cartItem.getMobileId());
            ps.setString(2, cartItem.getcEmail());
            ps.setInt(3, cartItem.getQuantity());
            ps.setString(4, m.getModel());
            ps.setDouble(5, m.getPrice());
            ps.setDouble(6, totalPrice);

            row = ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return row > 0;
    }

    @Override
    public List<CartItem> showCartList() {
        List<CartItem> clist = new LinkedList<>();
        con = DBUtility.getConnect();
        String sql = "SELECT * FROM cartitem";
        try {
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                CartItem cartItem = new CartItem();
                cartItem.setCartid(rs.getInt("cartid"));
                cartItem.setMobileId(rs.getInt("mobileId"));
                cartItem.setcEmail(rs.getString("cEmail"));
                cartItem.setQuantity(rs.getInt("quantity"));
                cartItem.setMobileName(rs.getString("mobileName"));
                cartItem.setMobilePrice(rs.getDouble("mobilePrice"));
                cartItem.setTotalPrice(rs.getDouble("totalPrice"));

                clist.add(cartItem);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return clist;
    }

    @Override
    public List<CartItem> searchCartByEmailId(String cEmail) {
        List<CartItem> clist = new LinkedList<>();
        con = DBUtility.getConnect();
        String sql = "SELECT * FROM cartitem WHERE cEmail = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, cEmail);
            rs = ps.executeQuery();
            while (rs.next()) {
                CartItem cart = new CartItem();
                cart.setCartid(rs.getInt("cartid"));
                cart.setMobileId(rs.getInt("mobileId"));
                cart.setcEmail(rs.getString("cEmail"));
                cart.setQuantity(rs.getInt("quantity"));
                cart.setMobileName(rs.getString("mobileName"));
                cart.setMobilePrice(rs.getDouble("mobilePrice"));
                cart.setTotalPrice(rs.getDouble("totalPrice"));
                clist.add(cart);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return clist;  // Return the list of CartItem objects
    }

    @Override
    public CartItem searchById(int cartid) {
        CartItem cart = null;
        con = DBUtility.getConnect();
        String sql = "SELECT * FROM cartitem WHERE cartid = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, cartid);
            rs = ps.executeQuery();
            if (rs.next()) {
                cart = new CartItem();
                cart.setCartid(rs.getInt("cartid"));
                cart.setMobileId(rs.getInt("mobileId"));
                cart.setcEmail(rs.getString("cEmail"));
                cart.setQuantity(rs.getInt("quantity"));
                cart.setMobileName(rs.getString("mobileName"));
                cart.setMobilePrice(rs.getDouble("mobilePrice"));
                cart.setTotalPrice(rs.getDouble("totalPrice"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return cart;
    }

    @Override
    public boolean deleteCartById(int cartid) {
        con = DBUtility.getConnect();
        String sql = "DELETE FROM cartitem WHERE cartid = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, cartid);
            row = ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return row > 0;
    }

    @Override
    public boolean deleteCartByEmail(String email) {
        con = DBUtility.getConnect();
        String sql = "DELETE FROM cartitem WHERE cEmail = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, email);
            row = ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return row > 0;
    }

    @Override
    public boolean updateCart(int cartid, int quantity) {
        con = DBUtility.getConnect();
        try {
            // Update quantity
            String sql = "UPDATE cartitem SET quantity = ? WHERE cartid = ?";
            ps = con.prepareStatement(sql);
            ps.setInt(1, quantity);
            ps.setInt(2, cartid);
            row = ps.executeUpdate();

            if (row > 0) {
                // Get updated item
                CartItem cart = searchById(cartid);
                double totalPrice = cart.getMobilePrice() * quantity;

                // Update totalPrice
                sql = "UPDATE cartitem SET totalPrice = ? WHERE cartid = ?";
                ps = con.prepareStatement(sql);
                ps.setDouble(1, totalPrice);
                ps.setInt(2, cartid);
                int row2 = ps.executeUpdate();

                return row2 > 0;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }
}
